import React from 'react';
import './App.css';
import NavigationBar from './Components/NavigationBar'; 
import "./Components/Fontawesome/font";
function App() {
  return (
    <div className="App">
      <NavigationBar />
    </div>
  );
}

export default App;
