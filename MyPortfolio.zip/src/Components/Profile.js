import React from 'react';
import './Styles/Profile.css';

 function Profile() {
    return (
        <>
            <section className="profile">
                <div className="heading-secondary">
                    <h1>Profile section</h1>
                </div>
                <div className="row">
                    <div className="col">

                    </div>
                    <div className="col">

                    </div>

                </div>
            </section>  
        </>
    )
}

export default Profile;