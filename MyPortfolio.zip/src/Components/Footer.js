import React from 'react';
import './Styles/Footer.css';

 function Footer() {
    return (
        <>
          <footer>
            <p>Copyright @ <span>2020</span></p>
        </footer>   
        </>
    )
}

export default Footer;